 module.exports = {
'employee': {
        queryStringBasic: 'SELECT sapid,employee_name,edc FROM nessu.employee',
        queryStringExpanded: 'SELECT * FROM nessu.employee',
        id: 'sapid',
         name:'employee_name',
         edc:'edc' ,    
        queryParameters: {
            employee_name: 'EmployeeName = \'{employee_name}\'',
            edc: 'EDC = \'{edc}\''
        }
    },

    'addEmployee': {
        restSemantic: "POST",
        table: 'nessu.employee',
        path: '/employee'
    },
    'deleteSapId': {
        restSemantic: "DELETE",
        table: 'nessu.employee',
        idName: 'sapid',
        path: '/employee/:sapid',
        queryParameters: {
            employee_name: 'employee_name = \'{employee_name}\'',
            edc: 'edc = \'{edc}\''
        }
    }
        }