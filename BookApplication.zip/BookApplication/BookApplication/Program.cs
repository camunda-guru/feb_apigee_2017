﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Usergrid.Sdk;
using Usergrid.Sdk.Model;

namespace BookApplication
{
    class Program
    {
        static void Main(string[] args)
        {
           // var client = new Client("iiht", "Banking");
           // //client.Login("eswaribala@rediffmail.com", "b3U6QDkH1m1IsZSM7p0LXOmbaEKdTQk", AuthType.None);            
           // //To retrieve specific book
           // //Book book = client.GetEntity<Book>("/books/6359be3a-6688-11e6-9a57-01434a358864", "");
           // //Console.WriteLine(book.name);
           // Employee emp = client.GetEntity<Employee>("/employees/31a207aa-a583-11e6-b4d7-03fe949d2860", "");
           // Console.WriteLine(emp.name);

           //UsergridCollection<Employee> data =client.GetEntities<Employee>("employees");
           //foreach(Employee empobj in data)
           //{
           //    Console.WriteLine("Name={0}\tProject={1}\tLocation={2}\n",empobj.name,empobj.project,empobj.location);

           //}

            var client = new Client("iiht", "Banking");

            UsergridCollection<Transaction> data = client.GetEntities<Transaction>("transactions");
            foreach (Transaction obj in data)
            {
                Console.WriteLine("Id={0}\tDate={1}\tAmount={2}\n", obj.TransactionId, obj.DOT, obj.Amount);

            }


            Console.ReadLine();
        }
    }
}
