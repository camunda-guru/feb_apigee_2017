﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookApplication
{
    public class Book
    {
        public String uuid { get; set; }
        public String name { get; set; }
        //public String author { get; set; }
       // public String title { get; set; }
    }
}
