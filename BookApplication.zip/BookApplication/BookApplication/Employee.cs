﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookApplication
{
    class Employee
    {
        public String uuid { get; set; }
        public String name { get; set; }
        public String project { get; set; }
        public String location { get; set; }


    }
}
