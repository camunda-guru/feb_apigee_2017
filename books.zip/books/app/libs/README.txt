Before running please add the apigee-android jar here.  

Once you have done so open the project in Android Studio, please make sure that you press the "Sync Project With Gradle Files" menu item.
